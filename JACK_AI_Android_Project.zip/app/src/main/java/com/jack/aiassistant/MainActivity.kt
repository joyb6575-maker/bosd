package com.jack.aiassistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

private val Background = Color(0xFF070B16)
private val Panel = Color(0xFF101A2D)
private val Cyan = Color(0xFF54DFFF)
private val Purple = Color(0xFF8C72FF)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { JackApp(onSpeak = ::speak, onLaunchApp = ::launchApp) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("bn", "BD")
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jack_reply")
    }

    private fun launchApp(name: String): String {
        val packageName = when (name.lowercase(Locale.ROOT)) {
            "youtube" -> "com.google.android.youtube"
            "chrome" -> "com.android.chrome"
            "settings", "setting" -> return try {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                "সেটিংস খুলছি।"
            } catch (_: Exception) { "সেটিংস খোলা যায়নি।" }
            else -> return "এই অ্যাপের নাম চিনতে পারিনি। YouTube, Chrome বা Settings বলো।"
        }
        return try {
            val launch = packageManager.getLaunchIntentForPackage(packageName)
            if (launch != null) {
                startActivity(launch)
                "$name খুলছি।"
            } else "এই ফোনে $name পাওয়া যায়নি।"
        } catch (_: Exception) { "$name খোলা যায়নি।" }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }
}

data class ChatMessage(val text: String, val fromUser: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun JackApp(
    onSpeak: (String) -> Unit,
    onLaunchApp: (String) -> String
) {
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var assistantOn by remember { mutableStateOf(true) }
    val messages = remember {
        mutableStateListOf(
            ChatMessage("হ্যালো! আমি JACK AI। বাংলায় বলো, কী সাহায্য লাগবে?", false)
        )
    }

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        listening = false
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
            input = spoken
        }
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startSpeech(speechLauncher) else {
            messages.add(ChatMessage("মাইক্রোফোনের অনুমতি ছাড়া ভয়েস ইনপুট চালু করা যাবে না।", false))
        }
    }

    val transition = rememberInfiniteTransition(label = "orb")
    val pulse by transition.animateFloat(
        initialValue = 0.96f, targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ), label = "pulse"
    )

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, secondary = Purple, background = Background, surface = Panel
    )) {
        Scaffold(containerColor = Background) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("JACK AI", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("আপনার বাংলা AI সহকারী", fontSize = 12.sp, color = Cyan)
                    }
                    Text(if (assistantOn) "ON" else "OFF", color = if (assistantOn) Cyan else Color.Gray)
                    Switch(checked = assistantOn, onCheckedChange = {
                        assistantOn = it
                        if (!it) listening = false
                    })
                }

                Spacer(Modifier.height(18.dp))
                Box(
                    Modifier.size(142.dp).scale(if (assistantOn) pulse else 1f)
                        .background(
                            Brush.radialGradient(listOf(Color(0xFF174A70), Color(0xFF17133A), Background)),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        Modifier.size(86.dp).background(
                            Brush.linearGradient(listOf(Cyan, Purple)), CircleShape
                        ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("J", fontSize = 46.sp, fontWeight = FontWeight.ExtraBold, color = Background)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    when {
                        !assistantOn -> "সহকারী বন্ধ"
                        listening -> "শুনছি..."
                        else -> "তোমার কথা শুনতে প্রস্তুত"
                    }, color = Cyan, fontSize = 13.sp
                )
                Spacer(Modifier.height(14.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth()
                        .background(Panel, RoundedCornerShape(18.dp)).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(messages) { message ->
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
                        ) {
                            Text(
                                message.text,
                                modifier = Modifier.widthIn(max = 285.dp)
                                    .background(
                                        if (message.fromUser) Color(0xFF163B54) else Color(0xFF1A2440),
                                        RoundedCornerShape(14.dp)
                                    ).padding(12.dp),
                                color = Color.White, fontSize = 14.sp
                            )
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("বাংলায় লিখো...") },
                        maxLines = 3, shape = RoundedCornerShape(16.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    FilledTonalButton(
                        onClick = {
                            if (!assistantOn) return@FilledTonalButton
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
                                == PackageManager.PERMISSION_GRANTED) {
                                startSpeech(speechLauncher)
                                listening = true
                            } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        },
                        contentPadding = PaddingValues(12.dp)
                    ) { Text("🎙") }
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        val question = input.trim()
                        if (question.isEmpty() || !assistantOn) return@Button
                        messages.add(ChatMessage(question, true))
                        input = ""
                        val answer = when {
                            question.contains("youtube", true) -> onLaunchApp("youtube")
                            question.contains("chrome", true) -> onLaunchApp("chrome")
                            question.contains("সেটিংস") || question.contains("settings", true) -> onLaunchApp("settings")
                            question.contains("তোমার নাম") || question.contains("তোমার নাম কি") ->
                                "আমার নাম JACK AI।"
                            else -> "আমি তোমার কথা বুঝেছি। Gemini AI যুক্ত করতে নিরাপদ API/backend সেটআপ প্রয়োজন। আপাতত YouTube, Chrome ও Settings খোলার মতো কয়েকটি স্থানীয় কমান্ড চালাতে পারি।"
                        }
                        messages.add(ChatMessage(answer, false))
                        onSpeak(answer)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                ) { Text("পাঠাও", fontWeight = FontWeight.Bold) }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

private fun startSpeech(
    launcher: androidx.activity.result.ActivityResultLauncher<Intent>
) {
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
        putExtra(RecognizerIntent.EXTRA_PROMPT, "JACK AI-কে বাংলায় বলুন")
    }
    try { launcher.launch(intent) } catch (_: Exception) { }
}
