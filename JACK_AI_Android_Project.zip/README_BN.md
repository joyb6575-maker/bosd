# JACK AI — Android Starter Project

এটি JACK AI-এর একটি প্রাথমিক native Android starter project। এতে আছে:
- Kotlin + Jetpack Compose dark UI
- বাংলা চ্যাট UI
- Android Speech Recognizer দিয়ে ভয়েস ইনপুট (ডিভাইসে উপযুক্ত speech service থাকতে হবে)
- Android Text-to-Speech দিয়ে উত্তর শোনানোর চেষ্টা
- YouTube, Chrome এবং Settings খোলার কয়েকটি local command
- ON/OFF সুইচ

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি এখনো সম্পূর্ণ JARVIS নয়। Gemini API সংযোগ, প্রকৃত wake-word detection, background voice service, reminders, নিরাপদ backend, persistent history এবং পূর্ণ device automation এখনও বাস্তবায়িত হয়নি। UI-তে Gemini-এর উত্তর বলে কোনো ভুয়া উত্তর দেওয়া হয় না।

## Build
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3-compatible Gradle
- Android Studio বা compatible cloud Android build environment

প্রজেক্টটি ZIP হিসেবে আপলোড করে কোনো Android build environment-এ খুলে Gradle sync/build করতে হবে। ফোনে ZIP ফাইল থাকলেই সরাসরি APK হবে না।

## API key security
Gemini-এর production API key APK-তে রাখবে না। production ব্যবহারে backend বা officially supported secure integration ব্যবহার করো।

## Test on device
1. Build/install
2. Microphone permission অনুমোদন
3. বাংলা voice recognition পরীক্ষা
4. YouTube/Chrome/Settings command পরীক্ষা
5. TTS বাংলা voice availability পরীক্ষা
6. Screen OFF/background অবস্থায় wake word কাজ করে বলে ধরে নিও না—এটি এই starter-এ implement করা নেই.
